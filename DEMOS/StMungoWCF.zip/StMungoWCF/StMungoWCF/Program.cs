﻿
using StMungoWCFService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace StMungoWCF
{
    class Program
    {
        static void Main(string[] args)
        {
            Type typeOfService = typeof(StMungoService);
            using (ServiceHost host = new ServiceHost(typeOfService))
            {
                host.Open();
                Console.WriteLine("Wainting for connections on: \n" + host.BaseAddresses[0].ToString() + "\n(press enter to stop the service)");
                Console.ReadLine();
            }
        }
    }
}
