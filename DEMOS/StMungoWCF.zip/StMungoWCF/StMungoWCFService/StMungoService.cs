﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace StMungoWCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "StMungoService" in both code and config file together.
    public class StMungoService : IStMungoService
    {
        static MungoSystem mungoSystem = new MungoSystem();
        #region BetegSzolgáltatások
        public BetegAdat getBetegAdatok(int peopleID)
        {
            var betegInfo = mungoSystem.Betegek.FirstOrDefault(x => x.PeopleID == peopleID);
            var pplInfo = mungoSystem.People.FirstOrDefault(x => x.PeopleID == peopleID);
            BetegAdat value = new BetegAdat(betegInfo, pplInfo);
            return value;
        }
        public ObservableCollection<KortortenetAdat> getKortortenetekByBetegId(int betegID)
        {
            var adatok = new ObservableCollection<KortortenetAdat>();
            var kortortenetfej = mungoSystem.Kortortenet_fej.Where(x => x.BetegID == betegID).FirstOrDefault();
            var tetelek = mungoSystem.Kortortenet_tetel.Where(x => x.KortortenetFejID == kortortenetfej.KortortenetFejID);
            if (tetelek != null)
            {
                foreach (var item in tetelek)
                {
                    adatok.Add(new KortortenetAdat(kortortenetfej, item));
                }
            }
            return adatok;
        }
        public ObservableCollection<Idopontok> getIdopontokByBetegId(int betegId)
        {
            var adatok = new ObservableCollection<Idopontok>();
            var lista = mungoSystem.Idopontok.Where(x => x.BetegID == betegId);
            if (lista != null)
            {
                adatok = new ObservableCollection<Idopontok>(lista);
            }
            return adatok;
        }
        public void Beteg_SaveChanges(BetegAdat beteg)
        {
            if (beteg != null)
            {
                mungoSystem.People.Attach(beteg.PeopleInfo);
                var entry1 = mungoSystem.Entry(beteg.PeopleInfo);
                entry1.State = System.Data.EntityState.Modified;

                mungoSystem.Betegek.Attach(beteg.BetegInfo);
                var entry2 = mungoSystem.Entry(beteg.BetegInfo);
                entry2.State = System.Data.EntityState.Modified;
                mungoSystem.SaveChanges();
            }
        }

        #endregion
    }
}
