﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace StMungoWCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IStMungoService" in both code and config file together.
    [ServiceContract]
    public interface IStMungoService
    {
        #region BetegService
        [OperationContract]
        ObservableCollection<KortortenetAdat> getKortortenetekByBetegId(int betegID);
        [OperationContract]
        BetegAdat getBetegAdatok(int peopleID);
        [OperationContract]
        void Beteg_SaveChanges(BetegAdat beteg);
        [OperationContract]
        ObservableCollection<Idopontok> getIdopontokByBetegId(int betegId);
        #endregion
        
    }
    
}
