﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StMungoWCFService
{
    [DataContract]
    public class BetegAdat
    {
        [DataMember]
        public Betegek BetegInfo { get; set; }
        [DataMember]
        public People PeopleInfo { get; set; }
        public BetegAdat(Betegek binfo, People pplinfo)
        {
            this.BetegInfo = binfo;
            this.PeopleInfo = pplinfo;
        }
    }
    [DataContract]
    public class KortortenetAdat
    {
        [DataMember]
        public Kortortenet_fej Fej { get; set; }
        [DataMember]
        public Kortortenet_tetel Tetel { get; set; }
        public KortortenetAdat(Kortortenet_fej f, Kortortenet_tetel t)
        {
            Fej = f;
            Tetel = t;
        }

    }
}
