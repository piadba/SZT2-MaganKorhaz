﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using SZT2schema.Models;

namespace SZT2schema.Controllers
{
    public enum ViewTypes { Idopont, Adatok }
    public class BetegMainController : Bindable
    {
        public IBetegAdatok betegAdatok { get; private set; }
        public UserControl view { get; private set; }
        private IWCF myWCF;
        public IdopontCreator idopontCreator { get; private set; }
        public BetegMainController(IPeopleData ppl)
        {
            if (ppl != null)
            {
                myWCF = new WCF();
                betegAdatok = myWCF.getBetegAdatok(ppl);
                SetView(ViewTypes.Idopont);
            }
                idopontCreator = new IdopontCreator();
            //test
            SetView(ViewTypes.Idopont);
            betegAdatok = new BetegAdatok()
            {
                Email = "test@test.test",
                Gender = "Ferfi",
                Name = "Kiss Pista",
                Phone = "0666666666",
                TAJ = "0121356789",
                UserName = "pista22",
                Address = "2000 Test test u. 22",/*
                MothersName = "Kis Emese",
                BirthDate = DateTime.Parse("1768.12.10"),
                PlaceOfBirth = "Magyarország, Budapest",
                MaidenName = "Szürke Marha"*/
            };
        }
        public void SetView(ViewTypes viewType)
        {
            switch (viewType)
            {
                case ViewTypes.Idopont:
                    view = new Idopont_View(this);
                    break;
                case ViewTypes.Adatok:
                    view = new AdatMod_View(this);
                    break;
                default:
                    break;
            }
            OnPropertyChanged("view");
        }
        public void DeleteIdopont()
        {
            Idopont a = idopontCreator.createIdopont();
            if (betegAdatok.idopontok.Contains(a))
            {
                betegAdatok.idopontok.Remove(a);
            }
        }
        public void SaveIdopont()
        {
            betegAdatok.idopontok.Add(idopontCreator.createIdopont());
        }
        public void SaveChanges()
        {

        }
    }
    public class IdopontCreator : Bindable
    {

        public ObservableCollection<string> Orvosok { get; set; }
        public ObservableCollection<string> Times { get; set; }
        public string Comment { get; set; }
        public string Orvos { get; set; }
        public string selectedTime { get; set; }
        public DateTime date { get; set; }
        public Idopont Idopont { get; set; }
        public IdopontCreator(Idopont idopont=null)
        {
            Times = setTimes();
            Orvosok = setOrvosok();
            selectedTime = Times[0];
            date = DateTime.Now;
            if (idopont==null)
            {
                Idopont = new Idopont(true);
                Comment = Idopont.Comment;
                Orvos = Orvosok[0];
            }
            OnPropertyChanged("Orvosok");
            OnPropertyChanged("Times");

        }
        ObservableCollection<string> setOrvosok()
        {
            var a = new ObservableCollection<string>();
            for (int i = 0; i < 4; i++)
            {
                a.Add("Dr. Test Tester " + i + 1);
            }
            return a;
        }
        DateTime Createdatetime()
        {
            string ds = date.ToString("yyyy.MM.dd") + " " + selectedTime;
            string i = new DateTime(2016,10,12,8,10,10).ToString("yyyy.MM.dd HH:mm");
            DateTime dt = DateTime.ParseExact(ds, "yyyy.MM.dd HH:mm", CultureInfo.InvariantCulture);
            return dt;
        }
        public Idopont createIdopont()
        {
            this.Idopont.Datum = Createdatetime();
            this.Idopont.Orvos = this.Orvos;
            this.Idopont.Comment = this.Comment;
            return this.Idopont;
        }
        ObservableCollection<string> setTimes()
        {
            var a = new ObservableCollection<string>();
            for (int i = 0; i < 20; i++)
            {
                if ((i + 8)<10)
                {
                a.Add(i % 2 == 0 ? "0"+(i + 8) + ":00" : (i + 8) + ":30");
                }
                else
                {
                    a.Add(i % 2 == 0 ?(i + 8) + ":00" : (i + 8) + ":30");
                }

            }
            return a;
        }

    }

    public class Bindable : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName]string name = "")
        {
            PropertyChangedEventHandler h = PropertyChanged;
            if (h != null)
            {
                h(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
