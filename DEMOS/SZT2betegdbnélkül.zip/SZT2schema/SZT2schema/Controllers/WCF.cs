﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SZT2schema.Controllers;
using SZT2schema.Models;

namespace SZT2schema.Controllers
{
    class WCF : IWCF
    {
        public IBetegAdatok getBetegAdatok(IPeopleData pplData)
        {
            return new BetegAdatok();
        }

        public ObservableCollection<IIdopont> getIdopontokByBetegId(int betegId)
        {
            return new ObservableCollection<IIdopont>();
        }

        public ObservableCollection<IKortortenet> getKortortenetekByBetegId(int betegId)
        {
            return new ObservableCollection<IKortortenet>();
        }

        public void SaveChanges(IBetegAdatok beteg)
        {

        }
    }
}
