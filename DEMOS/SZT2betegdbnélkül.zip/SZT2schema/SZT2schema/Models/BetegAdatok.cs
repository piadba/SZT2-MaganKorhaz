﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZT2schema.Models
{
    public class Idopont : IIdopont
    {
        public DateTime Datum { get; set; }
        public string Orvos { get; set; }
        public string Comment { get; set; }
        public override bool Equals(object obj)
        {
            if (obj is Idopont)
            {
                var a = obj as Idopont;
                return Datum.Equals(a.Datum) && Orvos.Equals(a.Orvos) && Comment.Equals(a.Comment);
            }
            return false;
        }
        public Idopont(bool istest=false)
        {
            if (istest)
            {
                Orvos = "";
                Comment = "";
                Datum = new DateTime();
            }
        }
    }
    class BetegAdatok : IBetegAdatok
    {
        public string Address { get; set; }
        public int BetegID { get; set; }
        public string Email { get; set; }
        public string Gender { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public int PeopleID { get; set; }
        public string Phone { get; set; }
        public string UserName { get; set; }
        public string TAJ { get; set; }
        /*
        public string MothersName { get; set; }
        public DateTime? BirthDate { get; set; }
        public string PlaceOfBirth { get; set; }
        public string MaidenName { get; set; }
        */
        public Kortortenet ActKortortenet { get; set; }

        public ObservableCollection<IIdopont> idopontok { get; set; }
        public ObservableCollection<Kortortenet> Kortortenet { get; set; }
        public BetegAdatok()
        {
            idopontok = new ObservableCollection<IIdopont>();
            Kortortenet = new ObservableCollection<Models.Kortortenet>();
            //test
            Kortortenet.Add(new Kortortenet("test"));
            if (Kortortenet.Count > 0)
            {
                ActKortortenet = Kortortenet[0];
            }
        }
    }
    public class Kortortenet : IKortortenet
    {
        public DateTime? Datum { get; set; }

        public IKortortenetFej Fej { get; set; }

        public string Kezeles { get; set; }

        public string Orvos { get; set; }
        public string toBind
        {
            get
            {
                return String.Format("Orvos: {0}\nKezelés:\n{1}", Orvos, Kezeles);
            }
        }
        public Kortortenet() { }
        public Kortortenet(string test)
        {
            Datum = DateTime.Now;
            Fej = null;
            Orvos = "Dr. Kis Nagy";
            Kezeles = "nagyon fájt a lába ezért levágtuk ... stb. stb.";
        }
        public override string ToString()
        {
            string datum = Datum != null ? Datum.Value.ToShortDateString() : "-";
            return datum;
        }

    }
}
