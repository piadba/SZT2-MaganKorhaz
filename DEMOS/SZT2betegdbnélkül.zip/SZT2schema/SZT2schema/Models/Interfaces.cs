﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZT2schema.Models
{
    public interface IKortortenetFej
    {
          int KortortenetFejID { get; set; }
          Nullable<int> BetegID { get; set; }
          Nullable<short> Deleted { get; set; }
    }
    public interface IKortortenetAdat
    {
          int KortortenetTetelID { get; set; }
          Nullable<int> KortortenetFejID { get; set; }
          Nullable<System.DateTime> Datum { get; set; }
          string Orvos { get; set; }
          string Kezeles { get; set; }
          Nullable<short> Deleted { get; set; }
    }
    public interface IBetegTableData
    {
        int BetegID { get; set; }
        Nullable<int> PeopleID { get; set; }
        Nullable<short> Deleted { get; set; }
        string TAJ { get; set; }
    }
    public interface IPeopleData
    {
        int PeopleID { get; set; }
        string UserName { get; set; }
        string Password { get; set; }
        Nullable<int> Group { get; set; }
        Nullable<byte> Deleted { get; set; }
        string Name { get; set; }
        string Address { get; set; }
        string Gender { get; set; }
        string Email { get; set; }
        string Phone { get; set; }
    }
    public interface IIdopont
    {
        DateTime Datum { get; set; }
        string Orvos { get; set; }
        string Comment { get; set; }
    }
    public interface IBetegAdatok
    {
        int BetegID { get; set; }
        int PeopleID { get; set; }
        string UserName { get; set; }
        string Password { get; set; }
        string Name { get; set; }
        string Address { get; set; }
        string Gender { get; set; }
        string Email { get; set; }
        string Phone { get; set; }
        string TAJ { get; set; }
        ObservableCollection<Kortortenet> Kortortenet { get; set; }
        ObservableCollection<IIdopont> idopontok { get; set; }
    }
    public interface IWCF
    {
        ObservableCollection<IKortortenet> getKortortenetekByBetegId(int betegId);
        ObservableCollection<IIdopont> getIdopontokByBetegId(int betegId);
        IBetegAdatok getBetegAdatok(IPeopleData pplData);//peopleDatabol megkapja az adatait,kikeresi a pplId alapján a beteg tábla adatait és convertálja (IBetegAdatok)-ba
        void SaveChanges(IBetegAdatok beteg);
    }
    public interface IKortortenet
    {
        IKortortenetFej Fej { get; set; }
        Nullable<System.DateTime> Datum { get; set; }
        string Orvos { get; set; }
        string Kezeles { get; set; }
    }
}
