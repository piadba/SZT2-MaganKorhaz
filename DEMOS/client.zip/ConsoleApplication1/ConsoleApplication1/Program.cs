﻿using ConsoleApplication1.test;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            StMungoServiceClient client = new StMungoServiceClient();
            var answer = client.getBetegAdatok(36);
            Console.WriteLine(answer);
            Console.ReadLine();
        }
    }
}
