﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFTeszt01
{
    class OrvosAsszisztensGyogyszerKapcsolat
    {
        public string Megnevezes { get; set; }
        public int Id { get; set; }
    }
}
